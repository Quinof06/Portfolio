package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class Main
{
    static int CROSSWORD_SIZE_LENGTH = 10;
    static int CROSSWORD_SIZE_HEIGHT = 13;
    static String FILE_NAME = "src/main/resources/PuzzleInfo.txt";

    static String DELIMITER = ":";
    static ArrayList<PuzzleInfo> clueInfoList;
    static Scanner input = new Scanner(System.in);

    static Square[][]puzzleBoard;


    static boolean[][] letterLocations = new boolean[CROSSWORD_SIZE_LENGTH][CROSSWORD_SIZE_HEIGHT];
    public static void main(String[] args) throws FileNotFoundException
    {
        Utils fileHandler = new Utils(FILE_NAME, DELIMITER);

        clueInfoList = fileHandler.listOFClueInfo();
        getAnswerLocations();

        Crossword crossword = new Crossword(letterLocations, clueInfoList);
        crossword.printBoard();

        puzzleBoard = crossword.puzzle;



    }


    public static void getAnswerLocations(){
        for(PuzzleInfo clue : clueInfoList){

            if(clue.isHorizontal){
                for(int i = 0; i < clue.answer.length(); i++){
                    letterLocations[clue.col + i][clue.row] = true;
                }
            }else{
                for(int i = 0; i < clue.answer.length(); i++){
                    letterLocations[clue.col][clue.row + i] = true;
                }
            }


        }
    }

    public static boolean pickClue(){
        System.out.println("Enter H for a horizontal clue or V for a vertical clue, \n" +
                "then enter the number for the clue you want to make a guess for on a separate line");
        String userClueDirection = input.nextLine();
        String userClueNum = input.nextLine();
        for(PuzzleInfo clue : clueInfoList){
            if (Integer.parseInt(userClueNum) == clue.clueNum
            && userClueDirection.equals(clue.isHorizontalAsAString))
            {
                System.out.println(clue.clue);
                return true;
            }
        }
        return false;
    }

    public static void listAllClues(){
        for(PuzzleInfo clue : clueInfoList){
            if(clue.isHorizontal){
                System.out.println(clue.clueNum + ".) " + clue.clue);
            }
        }
        for(PuzzleInfo clue : clueInfoList){
            if(!clue.isHorizontal){
                System.out.println(clue.clueNum + ".) " + clue.clue);
            }
        }
    }

    public void makeGuess()
    {
        System.out.println("Which clue would you like to guess? ");

        String userClueDirection = input.nextLine();
        String userClueNum = input.nextLine();

        for(PuzzleInfo clue : clueInfoList)
        {
            if (Integer.parseInt(userClueNum) == clue.clueNum && userClueDirection.equals(clue.isHorizontalAsAString))
            {
                System.out.println("Please enter your guess");
                String guess = input.nextLine().toUpperCase();

                if(guess.equalsIgnoreCase(clue.answer))
                {
                    if(clue.isHorizontal)
                    {
                        for(int i = 0; i < clue.answer.length(); i++)
                        {
                            puzzleBoard[clue.col + i][clue.row].setDisplay(guess.charAt(i));
                        }
                    }else
                    {
                        for(int i = 0; i < clue.answer.length(); i++)
                        {
                            puzzleBoard[clue.col][clue.row + i] = ;
                        }
                    }
                }
            }else
            {
                System.out.println("Please enter a valid choice. \n" +
                        " Follow all the listed instructions.  \n" +
                        "To enter something on a new live just hit the enter key.");
            }
        }


    }
}