package org.example;

public class Square {
    char display;

    Square(char display){
        this.display = display;
    }

    public void setDisplay(char display) {
        this.display = display;
    }
}
