package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Utils {
    File file;
    Scanner fileInput;

    String DELIMITER;

    public Utils(String fileName, String DELIMITER) throws FileNotFoundException
    {
        file = new File(fileName);
        fileInput = new Scanner(file);

        this.DELIMITER = DELIMITER;


    }


    private boolean fileExists() {
        if (file.exists()) {
            return true;

        } else {
            System.out.println("Sorry, there was an error on our side.  It seems that the puzzle wont load.");
            return false;
        }
    }

    public ArrayList<PuzzleInfo> listOFClueInfo()
    {
        if(fileExists()){
            ArrayList<PuzzleInfo> clueList = new ArrayList<>();
            while(fileInput.hasNextLine()){
                String fileLine = fileInput.nextLine();
                if(fileLine.contains(DELIMITER)) {
                    String[] clueInfo = fileLine.split(DELIMITER);
                    int row = Integer.parseInt(clueInfo[0]);
                    int col = Integer.parseInt(clueInfo[1]);
                    String direction = clueInfo[2];
                    int clueNum = Integer.parseInt(clueInfo[3]);
                    String clue = clueInfo[5];
                    String answer = clueInfo[4];
                    PuzzleInfo newClue = new PuzzleInfo(row, col, direction, clueNum, clue, answer);
                    clueList.add(newClue);
                }

            }
            return clueList;
        }
        return null;
    }

}
