package org.example;

import java.util.ArrayList;

public class Crossword {


    public Square[][] puzzle;
    public Crossword(boolean[][] letterLocations, ArrayList<PuzzleInfo> puzzleInfoList){
        puzzle = new Square[letterLocations.length][letterLocations[0].length];
        for(int i = 0; i < letterLocations.length; i++){
            for (int j = 0; j < letterLocations[i].length; j++){
                if(letterLocations[i][j]){
                    puzzle[i][j] = new Square('.');
                }else{
                    puzzle[i][j] = new Square('*');
                }
            }
        }
        for(PuzzleInfo clue : puzzleInfoList){
            puzzle[clue.col][clue.row] = new Square((char)(clue.clueNum + '0'));
        }

    }

    public void printBoard(){
        for(int i = 0; i < puzzle.length; i++) {
            for (int j = 0; j < puzzle[i].length; j++) {
                System.out.print(puzzle[i][j].display + " \t");
            }
            System.out.println();
        }
    }



}
