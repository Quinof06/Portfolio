package org.example;

public class PuzzleInfo {
    int row;
    int col;

    String isHorizontalAsAString;
    boolean isHorizontal;
    int clueNum;
    String clue;
    String answer;

    public PuzzleInfo(int row, int col, String isHorizontal, int clueNum, String clue, String answer){
        this.row = row;
        this.col = col;
        this.clueNum = clueNum;
        this.clue = clue;
        this.answer = answer;
        this.isHorizontalAsAString = isHorizontal;

        this.isHorizontal = isHorizontal.equalsIgnoreCase("H");
    }
}
