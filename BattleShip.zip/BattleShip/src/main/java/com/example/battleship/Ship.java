package com.example.battleship;

public class Ship {

    int shipSize;

    int frequency;

    String name;


    public Ship(int shipSize,  int frequency, String name){
        this.shipSize = shipSize;
        this.frequency = frequency;
        this.name = name;

    }

    public int getShipSize() {
        return shipSize;
    }

    public int getFrequency() {
        return frequency;
    }

    public String getName(){
        return name;
    }
}
