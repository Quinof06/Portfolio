package com.example.battleship;

public class Cell {

    protected int xAxisLocation;
    protected int yAxisLocation;
    protected boolean isEmpty;
    protected boolean isGuessed;
    public Cell(int xAxisLocation, int yAxisLocation, boolean isEmpty){
        this.xAxisLocation = xAxisLocation;
        this.yAxisLocation = yAxisLocation;
        this.isEmpty = isEmpty;

    }

    public String getValue(){
        return "";
    }

    protected boolean getIsEmpty(){
        return isEmpty;
    }

    protected void setIsEmpty(boolean isEmpty){
        this.isEmpty = isEmpty;
    }

    public void setGuessed(boolean guessed) {
        isGuessed = guessed;
    }
}

