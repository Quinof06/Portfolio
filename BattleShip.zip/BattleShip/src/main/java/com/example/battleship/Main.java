package com.example.battleship;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static int number;
    static int letterNumber;
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Board board = new Board(11);




        System.out.println();

        Ship carrier = new Ship(5, 1, "Carrier");
        Ship battleShip = new Ship(4, 1, "Battle Ship");
        Ship cruiser = new Ship(3, 2, "Cruiser");
        Ship sub = new Ship(3, 1, "Submarine");
        Ship destroyer = new Ship(2, 4, "Destroyer");
        Ship[] shipList = new Ship[]{carrier, battleShip, cruiser, sub, destroyer};

        for (int i = 0; i < shipList.length; i++) {
            for (int j = 1; j < shipList[i].getFrequency() + 1; j++) {
                System.out.println("Where would you like to place your " + shipList[i].getName() + "?");
                String location = input.nextLine();
                assignLocation(location);
                if (!board.addShip(number, letterNumber, shipList[i].getShipSize())) {
                    j--;
                }

            }

        }

        while (true) {
            System.out.println("Make a guess: ");
            String location = input.nextLine();
            assignLocation(location);
            board.makeGuess(number, letterNumber);
            if(board.shipCount<=0){
                System.out.println("you won");
                break;
            }
        }
    }

    static void assignLocation(String location) {
        char letterTemp = location.charAt(0);
        char letter = Character.toUpperCase(letterTemp);
        number = Integer.parseInt(location.substring(1));
        letterNumber = ((int) letter) - 64;

    }

}




