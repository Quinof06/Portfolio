package com.example.battleship;

public class Enemy {
    Board enemyBoard = new Board(5);
}
