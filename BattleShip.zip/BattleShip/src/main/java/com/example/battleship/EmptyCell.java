package com.example.battleship;

public class EmptyCell extends Cell{

    boolean isMiss;
    public EmptyCell(int xAxisLocation, int yAxisLocation){
        super(xAxisLocation, yAxisLocation, true);
    }

    public String getValue(){
        if(isGuessed){
            return "O";
        }else{
            return "-";
        }
    }


}
