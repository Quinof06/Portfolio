package com.example.battleship;

public class ShipCell extends Cell {

    public ShipCell(int xAxisPosition, int yAxisPosition){
        super(xAxisPosition, yAxisPosition, false);
    }

    public String getValue(){
        if (isGuessed ){
            return "X";
        }else{
            return "S";
        }

    }

}


