package com.example.battleship;

public class Board {

    int boardSize;

    int shipCount;
    Cell[][] board;
    public Board(int size){
        boardSize = size;
        board = new Cell[size][size];

        for(int i = 0; i < board.length; i++){
            for(int j = 0; j < board[i].length; j++){

                board[i][j] = new EmptyCell(i,j);

                if (i == 0 && j != 0)
                    System.out.print(j + "  ");
                else if(j == 0 && i != 0)
                    System.out.print((char)(i+64) + "  ");
                else
                    System.out.print("-  ");

            }

            System.out.println("");
        }
    }

    public void printBoard(){

        for(int i = 0; i < board.length; i++){
            for(int j = 0; j < board[i].length; j++){

                if (i == 0 && j != 0)
                    System.out.print(j + "\t");
                else if(j == 0 && i != 0)
                    System.out.print((char)(i+64) + "\t");
                else
                    System.out.print(board[i][j].getValue() + "\t");

            }

            System.out.println("\t");
        }
    }

    public boolean addShip(int x, int y, int size) {
        if(boundsCheck(x, y, size)){

            if (canPlace(x, y, size)) {

                for (int k = 0; k <= size - 1; k++) {

                    board[y][x - k] = new ShipCell(y, x - k);
                    board[y][x - k].setIsEmpty(false);
                    shipCount++;
                }

                printBoard();
                return true;

            }else{
                System.out.println("invalid placement");
                return false;
            }
        }else{
            System.out.println("invalid placement");
            return false;
        }

    }

    public boolean makeGuess(int x, int y){
        board[y][x].setGuessed(true);
        printBoard();
        return !board[y][x].isEmpty;

    }
    public boolean canPlace(int x, int y, int size){
        for (int k = 0; k <= size - 1; k++) {
            if(!board[y][x - k].getIsEmpty()){
                return false;
            }

        }
        return true;
    }

    public boolean boundsCheck(int x, int y, int size){
        return size <= x && x >= 1 && y >= 1 && x <= boardSize - 1 && y <= boardSize - 1;
    }



}
