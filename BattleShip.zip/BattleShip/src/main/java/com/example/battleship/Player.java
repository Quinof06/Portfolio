package com.example.battleship;

public class Player {

}
